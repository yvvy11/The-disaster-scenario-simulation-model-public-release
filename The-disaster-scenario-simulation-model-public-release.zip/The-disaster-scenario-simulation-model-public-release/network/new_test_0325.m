%% 用来计算承灾体空间关联网络矩阵

% 判断两个承灾体之间的空间关联关系
clear;
clc;

%% 导入数据

buffer_data_dir = fullfile('data', 'network', 'buffered');
origin_data_dir = fullfile('data', 'network', 'original');
functional_data_dir = fullfile('data', 'network', 'functional_interrelations');

% 电力设施
dianli1_buffer_1 = imread(fullfile(buffer_data_dir, '电力设施点要素_Buffer1_栅格.tif'));
dianli2_buffer_1 = imread(fullfile(buffer_data_dir, '电力设施2高压线_Buffer1_栅格.tif'));


% 燃气设施
ranqi1_buffer_2 = imread(fullfile(buffer_data_dir, '燃气设施1面_Buffer2_栅格.tif'));
ranqi2_buffer_2 = imread(fullfile(buffer_data_dir, '燃气设施2燃气长输_Buffer2_栅格.tif'));
ranqi3_buffer_2 = imread(fullfile(buffer_data_dir, '燃气设施3管道运输_Buffer2_栅格.tif'));


% 河流
heliu_buffer_2 = imread(fullfile(buffer_data_dir, '河流湖泊_Buffer2_栅格.tif'));

% 建筑
building = imread(fullfile(buffer_data_dir, '建筑栅格连续版本.tif'));
building = building + 26970;

% 水利
shuili_buffer_1 = imread(fullfile(buffer_data_dir, '水工设施用地_Buffer1_栅格.tif'));

% 污水厂
wushuichang_buffer_4 = imread(fullfile(buffer_data_dir, '污水厂_Buffer4_栅格.tif'));

% 物流仓储
cangku_buffer_1 = imread(fullfile(buffer_data_dir, '物流仓储_Buffer1_栅格.tif'));

% 消防站
xiaofang_buffer_2 = imread(fullfile(buffer_data_dir, '消防站_Buffer2_栅格.tif'));

% 道路
daolu = imread(fullfile(buffer_data_dir, '中心城区道路_栅格.tif'));


%% 导入非缓冲数据

%电力设施
dianli1 = imread(fullfile(origin_data_dir, '电力设施点要素.tif'));
dianli2 = imread(fullfile(origin_data_dir, '电力设施2.tif'));

%燃气设施
ranqi1 = imread(fullfile(origin_data_dir, '燃气设施1.tif'));
ranqi2 = imread(fullfile(origin_data_dir, '燃气设施2.tif'));
ranqi3 = imread(fullfile(origin_data_dir, '燃气设施3.tif'));

%河流
heliu = imread(fullfile(origin_data_dir, '河流湖泊.tif'));

%水利
shuili = imread(fullfile(origin_data_dir, '水利.tif'));

%污水厂
wushuichang = imread(fullfile(origin_data_dir, '污水厂.tif'));

%物流仓储
cangku = imread(fullfile(origin_data_dir, '物流仓储.tif'));

%消防站
xiaofang = imread(fullfile(origin_data_dir, '消防站.tif'));


%% 
% 构建矩阵
% 初始化
n = 40224;
dc_kongjian = zeros(n,'logical');

[r,c] = size(building);

% 构建一个三维的承灾体矩阵
ears = zeros(r,c,12);
ears(:,:,1) = dianli1_buffer_1;
ears(:,:,2) = dianli2_buffer_1;
ears(:,:,3) = ranqi1_buffer_2;
ears(:,:,4) = ranqi2_buffer_2;
ears(:,:,5) = ranqi3_buffer_2;
ears(:,:,6) = xiaofang_buffer_2;
ears(:,:,7) = wushuichang_buffer_4;
ears(:,:,8) = shuili_buffer_1;
ears(:,:,9) = cangku_buffer_1;
ears(:,:,10) = daolu;
ears(:,:,11) = building;
ears(:,:,12) = heliu_buffer_2;


% 构建一个承灾体原始矩阵，用于计算同类承灾体间关联
ears_origin = zeros(r,c,12);
ears_origin(:,:,1) = dianli1;
ears_origin(:,:,2) = dianli2;
ears_origin(:,:,3) = ranqi1;
ears_origin(:,:,4) = ranqi2;
ears_origin(:,:,5) = ranqi3;
ears_origin(:,:,6) = xiaofang;
ears_origin(:,:,7) = wushuichang;
ears_origin(:,:,8) = shuili;
ears_origin(:,:,9) = cangku;
ears_origin(:,:,10) = daolu;   
ears_origin(:,:,11) = building; 
ears_origin(:,:,12) = heliu;



% 1 会被电力设施1影响
for i = 1:r
    for j = 1:c
        if ears(i,j,1) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 1
                    dc_kongjian(ears(i,j,1), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 2 会被电力设施2影响
for i = 1:r
    for j = 1:c
        if ears(i,j,2) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 2
                    dc_kongjian(ears(i,j,2), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 3 会被燃气设施1影响
for i = 1:r
    for j = 1:c
        if ears(i,j,3) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 3
                    dc_kongjian(ears(i,j,3), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 4 会被燃气设施2影响
for i = 1:r
    for j = 1:c
        if ears(i,j,4) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 4
                    dc_kongjian(ears(i,j,4), ears(i,j,k)) = true;
                end
            end
        end
    end
end


% 5 会被燃气设施3影响
for i = 1:r
    for j = 1:c
        if ears(i,j,5) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 5
                    dc_kongjian(ears(i,j,5), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 6 会被消防站影响
for i = 1:r
    for j = 1:c
        if ears(i,j,6) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 6
                    dc_kongjian(ears(i,j,6), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 7 会被污水厂影响
for i = 1:r
    for j = 1:c
        if ears(i,j,7) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 7
                    dc_kongjian(ears(i,j,7), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 8 会被水利影响
for i = 1:r
    for j = 1:c
        if ears(i,j,8) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 8
                    dc_kongjian(ears(i,j,8), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 9 会被仓库影响
for i = 1:r
    for j = 1:c
        if ears(i,j,9) ~=0
            for k = 1:12
                if ears(i,j,k) ~= 0 && k ~= 9
                    dc_kongjian(ears(i,j,9), ears(i,j,k)) = true;
                end
            end
        end
    end
end

% 12 会被河流影响
for i = 1:r
    for j = 1:c
        if ears(i,j,12) ~=0
            for k = 1:11
                if ears(i,j,k) ~= 0
                    dc_kongjian(ears(i,j,12), ears(i,j,k)) = true;
                end
            end
        end
    end
end


target_layers = 1:12; 
for k = target_layers
    % 提取同一层的两套数据
    layer_orig = ears_origin(:,:,k); % 受体层 (本体)
    layer_buff = ears(:,:,k);        % 施体层 (影响范围)
    
    for i = 1 : r
        for j = 1 : c
            val_o = layer_orig(i,j); % 这里是谁的本体？(受体)
            val_b = layer_buff(i,j); % 这里是谁的Buffer？(源)
            
            % 如果这里有一个本体，且被一个Buffer覆盖了
            % 并且这个Buffer不是它自己的
            if val_o ~= 0 && val_b ~= 0 && val_o ~= val_b
                
                % 【关键修改】只建立单向连接：源 -> 受体
                % val_b (Buffer拥有者) 影响 -> val_o (本体拥有者)
                dc_kongjian(val_b, val_o) = true;
                
                
            end
        end
    end
    
end

fprintf('有向关联矩阵构建完毕！\n');








% for tar = 1:12
%     for i = 1:r
%         for j = 1:c
%             if ears(i,j,tar) ~=0
%                 e1 = ears(i,j,tar);
%                 [e2_idx,e2_v] = find(ears(i,j,:)~=0 & ears(i,j,:)~=e1);
%                 for k = 1:length(e2_v)
%                     dc(e1,e2_v(k)) = 1;
%                 end
%             end
%         end
%     end
% end


% % 构建邻接矩阵（稀疏矩阵优化）
% max_node = max(ears(:)); % 自动获取最大节点编号
% dc_sparse = sparse(max_node, max_node);
% 
% % 直接处理整个数据，不分块
% size_ears = size(ears);
% for k = 1:size_ears(3)
%     % 获取当前层的非零元素位置
%     [i, j] = find(ears(:,:,k) ~= 0);
% 
%     % 提取对应的节点编号
%     nodes = ears(sub2ind(size(ears), i, j, k*ones(size(i))));
%     unique_nodes = unique(nodes);
% 
%     % 生成所有有效边
%     if length(unique_nodes) >= 2
%         [src, dest] = meshgrid(unique_nodes, unique_nodes);
%         mask = (src ~= dest);
%         dc_sparse = dc_sparse + sparse(src(mask), dest(mask), 1, max_node, max_node);
%     end
% end
% 
% % 去重并二值化
% dc_sparse = (dc_sparse > 0);

%%

% 构建功能关联
ranqi3_dianli_xls = xlsread(fullfile(functional_data_dir, '燃气面_电力.xls'));
ranqi2_dianli_xls = xlsread(fullfile(functional_data_dir, '燃气线_电力.xls'));
ranqi1_dianli_xls = xlsread(fullfile(functional_data_dir, '燃气点_电力.xls'));
ranqis_xls = xlsread(fullfile(functional_data_dir, '燃气_燃气近邻表.xls'));

dianli2_ranqi_xls = xlsread(fullfile(functional_data_dir, '电力线_燃气.xls'));
dianli1_ranqi_xls = xlsread(fullfile(functional_data_dir, '电力点_燃气.xls'));
dianlis_xls = xlsread(fullfile(functional_data_dir, '电力_电力近邻表.xls'));

daolu_ranqi_xls = xlsread(fullfile(functional_data_dir, '道路_燃气设施.xls'));
daolu_dianli_xls = xlsread(fullfile(functional_data_dir, '道路_电力设施0322.xls'));
daolus_xls = xlsread(fullfile(functional_data_dir, '道路数据.xlsx'));

% 整理数据
dianli1_ranqi = dianli1_ranqi_xls(:,6:7);
dianli2_ranqi = dianli2_ranqi_xls(:,6:7);
dianlis = dianlis_xls(:,5:6);

ranqi3_dianli = ranqi3_dianli_xls(:,6:7);
ranqi2_dianli = ranqi2_dianli_xls(:,6:7);
ranqi1_dianli = ranqi1_dianli_xls(:,6:7);
ranqis = ranqis_xls(:,5:6);

daolu_ranqi = daolu_ranqi_xls(:,[7,10]);
daolu_dianli = daolu_dianli_xls(:,[7,10]);
daolus = daolus_xls(:,4:5);

% 进行功能关联

dc_gongneng = zeros(n,'logical');
% 燃气与电力关联
for i = 1:length(ranqi3_dianli)
    dc_gongneng(ranqi3_dianli(i,1),ranqi3_dianli(i,2)) = true;
end
for i = 1:length(ranqi2_dianli)
    dc_gongneng(ranqi2_dianli(i,1),ranqi2_dianli(i,2)) = true;
end
for i = 1:length(ranqi1_dianli)
    dc_gongneng(ranqi1_dianli(i,1),ranqi1_dianli(i,2)) = true;
end

% 电力与燃气关联
for i = 1:length(dianli1_ranqi)
    dc_gongneng(dianli1_ranqi(i,1),dianli1_ranqi(i,2)) = true;
end
for i = 1:length(dianli2_ranqi)
    dc_gongneng(dianli2_ranqi(i,1),dianli2_ranqi(i,2)) = true;
end

% 电力与电力、燃气与燃气——就近原则
for i = 1:length(dianlis)
    dc_gongneng(dianlis(i,1),dianlis(i,2)) = true;
end
for i = 1:length(ranqis)
    dc_gongneng(ranqis(i,1),ranqis(i,2)) = true;
end

% 道路与电力
for i = 1:length(daolu_dianli)
    dc_gongneng(daolu_dianli(i,1),daolu_dianli(i,2)) = true;
    dc_gongneng(daolu_dianli(i,2),daolu_dianli(i,1)) = true;
end

% 道路与燃气
for i = 1:length(daolu_ranqi)
    dc_gongneng(daolu_ranqi(i,1),daolu_ranqi(i,2)) = true;
    dc_gongneng(daolu_ranqi(i,2),daolu_ranqi(i,1)) = true;
end

% 道路与道路
for i = 1:length(daolus)
    dc_gongneng(daolus(i,1)+1976, daolus(i,2)+1976) = true;
    dc_gongneng(daolus(i,2)+1976, daolus(i,1)+1976) = true;
end

% dc_sp2 = sparse(dc_gongneng);

%% 构建图

  %dc = dc_kongjian | dc_gongneng;%考虑空间关联和功能关联
   %dc = dc_kongjian ;   %仅考虑空间关联
  dc = dc_gongneng;%仅考虑功能关联
G = digraph(dc);
% inDegree = indegree(G);
% outDegree = outdegree(G);
% xlswrite(fullfile('outputs', 'indegree.xlsx'), inDegree);
% xlswrite(fullfile('outputs', 'outdegree.xlsx'), outDegree);
N = numnodes(G); % 获取节点总数 (应该约等于 40224)


%% 网络脆弱性评价

% 攻击节点选择
% 先从度最高的开始攻击
inDegree = indegree(G);
[sorted_inD, idx_inD] = sort(inDegree, 'descend');
top_idx = idx_inD(2);

G_fail = G;
G_fail = rmnode(G_fail, top_idx);

fail_indegree = indegree(G_fail);


%%  计算节点度
inDegree = indegree(G);
outDegree = outdegree(G);

% 排序
[sorted_inD, idx_inD] = sort(inDegree, 'descend');
[sorted_outD, idx_outD] = sort(outDegree, 'descend');
%% 
% %%  计算网络直径
D = distances(G);
 network_diameter = max(D(~isinf(D)), [], 'all');
 fprintf('网络直径 (Diameter):    %d\n', network_diameter);
%%  计算平均最短路径
 validPaths = D(~isinf(D) & D~=0);  % 只保留可达且非自身的路径
 averagePathLength = mean(validPaths);  % 求平均
fprintf('平均最短路径 (L):       %.4f\n', averagePathLength);

%% 

% %%  计算网络效率
 % D 是 N x N 的距离矩阵
N = size(D, 1);
eff_sum = 0;
valid_count = 0;

for i = 1:N
    for j = 1:N
        if i ~= j && isfinite(D(i,j))  % i≠j 且路径可达
            eff_sum = eff_sum + 1 / D(i,j);
            valid_count = valid_count + 1;
        end
    end
end

% 网络效率 = 平均的 1/dij
E = eff_sum / (N * (N - 1));  % 若你坚持用标准定义
fprintf('网络效率 (E):           %.6f\n', E);
%% 
%计算子网络指标
% 1. 定义子网络分组 (这里已经包含了名字，所以不需要 layer_names 了)
fprintf('%-15s | %-10s | %-10s | %-12s | %-12s\n', '子网络名称', '节点数', '直径', '平均路径', '网络效率');
fprintf('------------------------------------------------------------------------------------\n');

ids_1 = ears_origin(:,:,1); 
ids_2 = ears_origin(:,:,2);
node_ids = unique([ids_1(ids_1>0); ids_2(ids_2>0)]);
calc_and_print('电力设施子网络', G, node_ids);

ids_3 = ears_origin(:,:,3);
ids_4 = ears_origin(:,:,4);
ids_5 = ears_origin(:,:,5);
node_ids = unique([ids_3(ids_3>0); ids_4(ids_4>0); ids_5(ids_5>0)]);
calc_and_print('燃气设施子网络', G, node_ids);

ids = ears_origin(:,:,6);
node_ids = unique(ids(ids>0));
calc_and_print('消防站子网络', G, node_ids);

ids = ears_origin(:,:,7);
node_ids = unique(ids(ids>0));
calc_and_print('污水厂子网络', G, node_ids);

ids = ears_origin(:,:,8);
node_ids = unique(ids(ids>0));
calc_and_print('水利设施子网络', G, node_ids);

ids = ears_origin(:,:,9);
node_ids = unique(ids(ids>0));
calc_and_print('物流仓储子网络', G, node_ids);

ids = ears_origin(:,:,10);
node_ids = unique(ids(ids>0));
calc_and_print('道路子网络', G, node_ids);

ids = ears_origin(:,:,11);
node_ids = unique(ids(ids>0));
calc_and_print('建筑子网络', G, node_ids);

ids = ears_origin(:,:,12);
node_ids = unique(ids(ids>0));
calc_and_print('河流湖泊子网络', G, node_ids);



fprintf('------------------------------------------------------------------------------------\n');


function calc_and_print(name, G, node_ids)
    
    if isempty(node_ids)
        fprintf('%-15s | %-10d | %-10s | %-12s | %-12s\n', name, 0, '-', '-', '-');
        return;
    end

    % 1. 提取子图
    G_sub = subgraph(G, node_ids);
    N = numnodes(G_sub);

    if N < 2
        fprintf('%-15s | %-10d | %-10d | %-12s | %-12d\n', name, N, 0, '0', 0);
        return;
    end

    % 2. 计算距离矩阵 (硬算)
    D = distances(G_sub);

    % 3. 算直径
    valid_D = D(~isinf(D));
    if isempty(valid_D)
        dia = 0;
    else
        dia = max(valid_D, [], 'all');
    end

    % 4. 算平均路径
    validPaths = D(~isinf(D) & D~=0);
    if isempty(validPaths)
        avg_path = Inf;
    else
        avg_path = mean(validPaths);
    end

    % 5. 算效率
    inv_D = 1 ./ D;
    inv_D(isinf(D)) = 0;
    inv_D(eye(N,'logical')) = 0;
    E = sum(inv_D, 'all') / (N * (N - 1));

    % 打印
    fprintf('%-15s | %-10d | %-10d | %-12.4f | %-12.6f\n', name, N, dia, avg_path, E);
end



%% 度中心性计算
% 连边数/（总节点数-1）
% 入度中心性
DC_in = inDegree / (n-1);
mean_DC_in = mean(DC_in);
% 出度中心性
DC_out = outDegree / (n-1);

%% 介数中心性
bc = centrality(G, 'betweenness');

%% 计算路径数量

pathCounts = zeros(n, 'int8');
for i = 1:3
    pathCounts(i,:) = countSimplePaths(dc_sparse, i);
end

function pathCount = countSimplePaths(adjMatrix, startNode)
    % adjMatrix 是有向图的稀疏邻接矩阵
    % startNode 是路径的起始节点（从 1 开始计数）
    
    n = size(adjMatrix, 1); % 获取节点数量
    pathCount = zeros(1, n); % 初始化路径计数数组
    visited = zeros(1, n); % 初始化访问标记数组
    
    % 使用深度优先搜索（DFS）来统计路径数量
    function dfs(currentNode, depth)
        visited(currentNode) = true; % 标记当前节点为已访问
        [rows, cols] = find(adjMatrix(currentNode, :)); % 获取当前节点的邻接节点
        for nextNode = cols
            if ~visited(nextNode)
                dfs(nextNode, depth + 1); % 递归访问下一个节点
            end
        end
        visited(currentNode) = false; % 回溯时取消标记
        
        % 如果当前节点不是起点，则路径计数不增加
        if currentNode ~= startNode
            pathCount(currentNode) = pathCount(currentNode) + 1;
        end
    end
    
    dfs(startNode, 0); % 从起始节点开始DFS
end


% pathCounts = zeros(n, 'int8');
% for i = 1:n
%     pathCounts(i,:) = countSimplePaths(dc_sparse, i);
% end
% 
% 
% 
% function pathCount = countSimplePaths(adjMatrix, startNode)
%     % adjMatrix 是有向图的稀疏邻接矩阵
%     % startNode 是路径的起始节点（从1开始计数）
% 
%     n = size(adjMatrix, 1); % 获取节点数量
%     pathCount = zeros(1, n); % 初始化路径计数数组
%     visited = false(1, n); % 初始化访问标记数组
%     pathCount(startNode) = 1; % 起始节点的路径计数为1
% 
%     % 使用深度优先搜索（DFS）来统计路径数量
%     function dfs(currentNode, depth)
%         visited(currentNode) = true; % 标记当前节点为已访问
%         [rows, cols] = find(adjMatrix(currentNode, :)); % 获取当前节点的邻接节点
%         for nextNode = cols
%             if ~visited(nextNode)
%                 dfs(nextNode, depth + 1); % 递归访问下一个节点
%             end
%         end
%         visited(currentNode) = false; % 回溯时取消标记
%         if depth > 0
%             pathCount(currentNode) = pathCount(currentNode) + 1; % 更新路径计数
%         end
%     end
% 
%     dfs(startNode, 0); % 从起始节点开始DFS
% end






