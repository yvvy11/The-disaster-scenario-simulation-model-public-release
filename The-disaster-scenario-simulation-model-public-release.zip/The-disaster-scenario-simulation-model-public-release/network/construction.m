% 构建多层网络

%% 燃气网络

ranqi_A = xlsread("C:\Users\PC\Desktop\论文_颜吴\资料备份_ywy\资料备份\毕设实验\关联网络\网络表格\燃气设施new.xls");
[r_ranqi,c_ranqi] = size(ranqi_A);

node_ranqi = ranqi_A(:,11:12);

%节点1、2
node1_ranqi = node_ranqi(:,1);
node2_ranqi = tabulate([node_ranqi(:,2);0]);
node2_ranqi = node2_ranqi(2:end,1);
node_ranqi_list = [node1_ranqi; node2_ranqi];
n_ranqi = length(node_ranqi_list);
num1_ranqi = length(node1_ranqi);
num2_ranqi = n_ranqi - num1_ranqi;

% 节点1、2的连边情况
dc_ranqi = zeros(n_ranqi);

% 同类型节点相连
dc_ranqi(1:num1_ranqi,1:num1_ranqi) = 1;
dc_ranqi(num1_ranqi+1:end,num1_ranqi+1:end) = 1;
for i = 1:n_ranqi
    dc_ranqi(i,i) = 0;
end

% 不同类型节点根据就近原则相连
for i = 1:r_ranqi
    j = node_ranqi(i,2);
    dc_ranqi(i,j) = 1;
    dc_ranqi(j,i) = 1;
end


% 构造图
nodes_ranqi = {"1","2","3","4","5","6","7","8","9","10","11"};
G_ranqi = graph(dc_ranqi, 'upper');
plot(G_ranqi);


%% 电力网络

dianli_A = xlsread("C:\Users\PC\Desktop\论文_颜吴\资料备份_ywy\资料备份\毕设实验\关联网络\网络表格\电力设施.xls");
[r_dianli,c_dianli] = size(dianli_A);

node_dianli = dianli_A(:,[22,24]);

%节点1、2
node1_dianli = node_dianli(:,1);
node2_dianli = tabulate([node_dianli(:,2);0]);
node2_dianli = node2_dianli(2:end,1);
node_dianli_list = [node1_dianli; node2_dianli];
n_dianli = length(node_dianli_list);
num1_dianli = length(node1_dianli);
num2_dianli = n_dianli - num1_dianli;

% 节点1、2的连边情况
dc_dianli = zeros(n_dianli);

% 同类型节点相连
dc_dianli(1:num1_dianli,1:num1_dianli) = 1;
dc_dianli(num1_dianli+1:end,num1_dianli+1:end) = 1;
for i = 1:n_dianli
    dc_dianli(i,i) = 0;
end

% 不同类型节点根据就近原则相连
for i = 1:r_dianli
    j = node_dianli(i,2);
    dc_dianli(i,j) = 1;
    dc_dianli(j,i) = 1;
end


% 构造图
nodes_dianli = {"1","2","3","4","5","6","7","8","9","10","11"};
G_dianli = graph(dc_dianli, 'upper');
plot(G_dianli);


%% 道路网络


roads_A = xlsread("C:\Users\PC\Desktop\论文_颜吴\资料备份_ywy\资料备份\毕设实验\关联网络\网络表格\道路数据.xlsx");
[r_roads,c_roads] = size(roads_A);
n_roads = 24993;


node_roads = roads_A(:,4:5);

% 去重
node_roads_clean = remove_u_pairs(node_roads);


G_roads = graph(node_roads_clean(:,1),node_roads_clean(:,2));

plot(G_roads);

[bin_roads, binsize_roads] = conncomp(G_roads);

node11_roads = 8155;
node22_roads = 9441;
isConnected = (bin_roads(node11_roads) == bin_roads(node22_roads));


%% 构建多层网络

% multilayerNet = struct();
% multilayerNet.layers = {};
% multilayerNet.interlayer_edges = [];
% multilayerNet.interlayer_rules = [];
% 
% % 第一层：燃气网络
% layer_ranqi = G_ranqi;
% name_ranqi = compose('燃气%02d', 1:n_ranqi)';
% layer_ranqi.Nodes.Name = name_ranqi;
% multilayerNet.layers{1} = layer_ranqi;
% 
% 
% % 第二层：电力网络
% layer_dianli = G_dianli;
% name_dianli = compose('电力%02d', 1:n_dianli)';
% layer_dianli.Nodes.Name = name_dianli;
% multilayerNet.layers{2} = layer_dianli;
% 
% % 第三层：道路网络
% layer_roads = G_roads;
% name_roads = compose('道路%05d', 1:n_roads)';
% layer_roads.Nodes.Name = name_roads;
% multilayerNet.layers{3} = layer_roads;
% 
% 
% %  不同层的节点之间的关联——空间关联可以考虑加在这个里面
% 
% % % Alice（层1节点1）与 Alice（层2节点1）连接
% % multilayerNet.interlayer_edges = [1 1 2 1]; 
% % 
% % % Bob（层1节点2）与 Bob（层2节点2）连接
% % multilayerNet.interlayer_edges = [multilayerNet.interlayer_edges; 1 2 2 2];
% 
% 
% % 层间关联
% num_layers = 3;
% 
% % 层间邻接矩阵（例如层1↔层2，层2↔层3）
% layer_adj = [0 1 1; 
%              1 0 1; 
%              1 1 0]; 
% 
% % 存储层间连接规则
% multilayerNet.interlayer_rules = layer_adj;
% 
% 
% isConnected = hasedge(multilayerNet, '燃气01', '道路20000');


%% 输入数据示例
% 层1：3个节点（ID:1,2,3），邻接矩阵
layer{1}.adj = dc_ranqi; 
layer{1}.nodes = [1:n_ranqi]; % 该层包含的全局节点ID

% 层2：4个节点（ID:2,3,4,5），邻接矩阵 
layer{2}.adj = dc_dianli;
layer{2}.nodes = [1:n_dianli] + n_ranqi;

% 层间连接规则（示例：允许相邻ID跨层连接）
cross_layer_rule = @(id1, id2) abs(id1 - id2) == 1; % 自定义连接条件

%% 构建超图邻接矩阵
% 收集所有节点ID
all_nodes = unique([layer{1}.nodes, layer{2}.nodes]); % 本例得到[1,2,3,4,5]
n_total = length(all_nodes);

% 初始化超邻接矩阵
super_adj = sparse(n_total, n_total);

% 填充层内连接
for i = 1:length(layer)
    [~, idx] = ismember(layer{i}.nodes, all_nodes); % 找到全局ID对应的矩阵位置
    super_adj(idx, idx) = max(super_adj(idx, idx), layer{i}.adj); % 保留已有连接
end

% 添加跨层连接
for i = 1:n_total
    for j = 1:n_total
        if cross_layer_rule(all_nodes(i), all_nodes(j))
            super_adj(i,j) = 1; % 根据规则添加跨层边
        end
    end
end

%% 计算连通分量
G = graph(super_adj);
bins = conncomp(G);
disp('全局连通分量分布:');
arrayfun(@(x) fprintf('节点%d → 分量%d\n', all_nodes(x), bins(x)), 1:n_total)

%% 可视化（突出显示跨层连接）
plot(G, 'NodeLabel', all_nodes, 'Layout', 'force', 'UseGravity', true);
title('异构多层网络连通性');




%% function
function result = remove_u_pairs(arr)
       
    % 对每行元素排序（标准化处理）
    sorted_arr = sort(arr, 2);
    
    % 获取唯一行的首次出现索引
    [~, idx] = unique(sorted_arr, 'rows', 'stable');
    
    result = arr(idx, :);
end

