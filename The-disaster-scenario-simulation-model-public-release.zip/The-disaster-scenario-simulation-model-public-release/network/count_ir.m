
building_type_num = 4;
lisan_num = 10;

url1 = fullfile('data', 'network', 'dc-matrix.xlsx');
savepath = fullfile('outputs', 'network');
dc = xlsread(url1);
dc = dc(3:end,:);
[num_hp,n] = size(dc);
ir_e = zeros(n);
ir_hp = zeros(num_hp);

for hp = 1:num_hp
    for ei = 1:n
        for j = 1:n
            if j ~= ei && dc(hp,j) ~= 0
                if dc(hp,ei) == 3
                    ir_e(ei,j) = 1;
                elseif (dc(hp,ei)==2)&&(dc(hp,j)~=3)
                    ir_e(ei,j) = 1;
                end
            end
        end
    end
end

for ei = 1:n
    for hp1 = 1:num_hp
        for hp2 = 1:num_hp
            if hp1 ~= hp2 && dc(hp1,ei) ~= 0
                if dc(hp2,ei) == 2 || dc(hp2,ei) == 3
                    ir_hp(hp1,hp2) = 1;
                end
            end
        end
    end
end

filename1 = 'ir_e.xls';
filename2 = 'ir_hp.xls';
sheet = 1;
xlswrite(fullfile(savepath, filename1),ir_e,sheet);
xlswrite(fullfile(savepath, filename2), ir_hp,sheet);

save(fullfile(savepath, 'ir_e.mat'),'ir_e');
save(fullfile(savepath, 'ir_hp.mat'),'ir_hp');

nodes_e = {'e1', 'e2', 'e3', 'e4', 'e5', 'e6', 'e7', 'e8', 'e9', 'e10', 'e11'};
nodes_h = {'h0', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'h7'};

G = digraph(ir_e(4:end,4:end),nodes_e);
plot(G);
