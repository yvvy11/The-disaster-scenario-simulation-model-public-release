function [rc,dh0] = f_rc_dh0(testnum)
rclist = [0.095,0.1,0.105,0.11,0.115,0.12,0.125];
dh0list = [1.47,1.475,1.48,1.485,1.49,1.495,1.5];



if testnum <=7
    dh0 = 1.48;
    rc = rclist(testnum);
elseif testnum > 7
    dh0 = dh0list(testnum-7);
    rc = 0.105;
end
end