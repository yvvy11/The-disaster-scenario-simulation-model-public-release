% rc分布图

%% 导入数据
% 医院rc

% 避难场所rc

% 消防站rc


% 综合脆弱性
ci_list = cell2mat(struct2cell(load('G:\ywy\00毕业论文\实验\rc\ci_list.mat')));

xy_lisan = cell2mat(struct2cell(load('G:\ywy\00毕业论文\毕业论文\实验结果0209\test1\xy_lisan.mat')));
xy_b = cell2mat(struct2cell(load('G:\ywy\00毕业论文\毕业论文\实验结果0209\test1\xy_b.mat')));
ci_ears = zeros([row,col]);

for i = 1:size(xy_lisan,1)
    x = xy_lisan(i,3);
    y = xy_lisan(i,4);
    if xy_lisan(i,1) ~= 0
        ci_ears(x,y) = ci_list(xy_lisan(i,1));
    elseif xy_b(i,1) ~= 0
        ci_ears(x,y) = ci_list(xy_b(i,1));
    end
end

%% 画图
% 无数据的不填色
s1 = ones([row,col]) .* ci_ears;
s1(s1~=0) = 1;


barnum = 12;
h = image(ci_ears*256); hold on;
set(h,'alphadata',s1);
daspect([1 1 1]);

colormap(slanCM(barnum));
c=colorbar;
c.AxisLocation = 'out';
c.Label.String = ' ears’ CI';
c.Label.FontSize = 14;
c.Label.FontWeight = 'bold';
c.Direction = 'normal';
clim([0, 1]);
c.Ticks = (0:0.1:1)*256;
% c.TickLabels = {'0','0.02','0.04','0.06','0.08','0.10','0.12','0.14','0.16','0.18','0.20'};
c.TickLabels = {'0','0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9','1'};
set(gca, 'XTickLabel', [], 'YTickLabel', []);



%% 画图
