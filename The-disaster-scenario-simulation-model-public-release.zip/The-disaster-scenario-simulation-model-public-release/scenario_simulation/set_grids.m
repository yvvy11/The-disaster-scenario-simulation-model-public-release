function [grids] = set_grids(grids_item, grids_class)
    if ~exist('grids_class','var')
        grids_class = grids_item;
    end
    [row,col] = size(grids_item);
    grids = dictionary;
    for i = 1:row
        for j = 1:col
            if grids_item(i,j) ~= 0
                if grids.numEntries == 0
                    grids(grids_item(i,j)) = {[grids_class(i,j),i,j]};
                    continue;
                end
                if grids.isKey(grids_item(i,j)) 
                    grids(grids_item(i,j)) = {[cell2mat(grids(grids_item(i,j)));[grids_class(i,j),i,j]]};
                else
                    grids(grids_item(i,j)) = {[grids_class(i,j),i,j]};
                end
            end
        end
    end
end