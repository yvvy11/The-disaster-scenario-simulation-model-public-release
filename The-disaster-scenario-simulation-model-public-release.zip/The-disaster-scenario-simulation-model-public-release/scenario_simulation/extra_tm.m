function [tm,row_index,col_index] = extra_tm(TM)
[row_index, col_index] = find(TM ~= 0);
n = length(row_index);
tm = zeros(n);
for i = 1:n
    for j = 1:n
        tm(i,j) = TM(row_index(i),col_index(j));
    end
end