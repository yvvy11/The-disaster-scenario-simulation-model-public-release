
function[S2t,Di_t,TM_ir_t] = S2_t(miu,theta,Vi,ds,ears_b,ears_lisan,Dt_1,Si_0,grids_build,grids_discrete,ir,lumc_b,lumc_sp)

[z,~] = size(Vi);
TM_ir_t = zeros(z,z);
SAI = zeros(z,1);
S2t = zeros(z,1);
[row,col] = size(lumc_b);
num_building = size(ears_b,1);


% 计算t时刻承灾体ej释放的危险强度currDjt
Curr = zeros(z,1);
for p = 1:z
    Curr(p) = CurrDjT(Dt_1(p),miu,Si_0(p),theta);
end


% 对于每一个ei in z中，循环迭代
grids = dictionary;
for i = 1:num_building
    grids(i) = {get_grids(i, grids_build)};
end
for i = (num_building+1):z
    grids(i) = {get_grids(i-num_building, grids_discrete)};
end


for i = 1:z
    % 1、计算Ki
    if i <= num_building% i属于建筑
        Ki = ears_b(i,3);
    elseif i > num_building % i属于离散要素
        Ki = ears_lisan(i-num_building,3);
    end
    sum = 0;
    grid_i = cell2mat(grids(i));
    ei_row = grid_i(:,1);
    ei_col = grid_i(:,2);
    nei = size(ei_col);
    % 3、对于某一ei，计算距离rji和rej，并计算强度D(ji)t

    ds_max = max(ds);
    row_max = (max(ei_row)+ds_max <= row)*(max(ei_row)+ds_max)+(max(ei_row)+ds_max > row)*row;
    row_min = (min(ei_row)+ds_max <= row)*(min(ei_row)+ds_max)+(min(ei_row)+ds_max > row)*row;
    col_max = (max(ei_col)+ds_max <= col)*(max(ei_col)+ds_max)+(max(ei_col)+ds_max > col)*col;
    col_min = (min(ei_col)+ds_max <= col)*(min(ei_col)+ds_max)+(min(ei_col)+ds_max > col)*col;
    a1 = lumc_b(row_min:row_max,col_min:col_max);
    a2 = lumc_sp(row_min:row_max,col_min:col_max);
    t1 = tabulate(reshape(a1,[1,(row_max-row_min+1)*(col_max-col_min+1)]));
    t2 = tabulate(reshape(a2,[1,(row_max-row_min+1)*(col_max-col_min+1)]));
    index = [t1(2:end,1);t2(2:end,1)+num_building];
    for j = reshape(index,1,length(index))
        Min = 500;
        if j ~= i
            % 找到Kji
            % 1 找到代号为ei/ej的要素代表的所有栅格
            grid_j = cell2mat(grids(j));
            ej_row = grid_j(:,1);
            ej_col = grid_j(:,2);
            nej = size(ej_col);
            % 2 找到ei和ej的最小距离rji
            for k = 1 : nei(1,1)
                dmin = 500;
                for q = 1 : nej(1,1)
                    dis = dist(ei_row(k),ei_col(k),ej_row(q),ej_col(q));
                    % if dis <= ds(j)
                    %     sum = sum + Curr(j);
                    % elseif dis > ds(j)
                    %     sum = sum + Curr(j)/dis/dis;
                    % end
                    dmin = min([dis,dmin]);
                    Min = min([dis,Min]);
                end
                if dmin < ds(j) % 第k个栅格点在ej影响范围内
                    index = find(ej_row == ei_row(k));
                    flag = ismember(ei_col(k),ej_col(index));
                    if (not(isempty(index))) && (double(flag))
                        sum = sum + Curr(j);
                    else
                        sum = sum + Curr(j)/dmin/dmin;
                    end

                end
            end

            if Min > ds(j)
                r = 0;
            else
                r = 1;
            end

            if (ir(i,j) == 1) & (r == 1)
                TM_ir_t(i,j) = 1;
                SAI(i) = SAI(i) + sum/Ki ;
            end
            sum = 0;
        end

    end

    S2t(i) = SAI(i) .* Vi(i);

end


Di_t = Dt_1 - Curr;

end






function [d] = dist(x1,y1,x2,y2)
d = sqrt((x1-x2)^2+(y1-y2)^2);
end

function [Cur] = CurrDjT(D_t,miu,S_t,theta)

Cur = D_t * (1-exp(-miu*S_t))/(1+exp(-miu*(S_t-theta)));
end

