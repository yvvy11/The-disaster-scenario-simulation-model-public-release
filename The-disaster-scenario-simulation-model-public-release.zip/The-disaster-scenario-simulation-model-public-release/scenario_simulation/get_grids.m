function [grids] = get_grids(i, grids)
    row_col = cell2mat(grids(i));
    grids = row_col(:,2:3);
end