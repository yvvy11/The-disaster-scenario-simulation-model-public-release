
%% 网络攻击实验结果at
count = 100;
testnum = 100;
p_list = zeros(count,testnum);
z = 40224;

name1 = ['G:\ywy\00毕业论文\实验\关联网络\网络数据\attack_test\0412\p_'];
name2 = ['\p_count'];
% name2 = ['_dh00.0168\p_count'];
name3 = ['_quota'];
name4 = ['_k'];
name5 = ['.mat'];

for test = 1:testnum
    quota = 0.01*test;
    failn = z * quota;
    for i = 1:count
        name = [name1 num2str(count) name2 num2str(count) name3 num2str(quota) name4 num2str(i) name5 ];
        p = cell2mat(struct2cell(load(name)));
        p_list(i,test) = p*(failn*(failn - 1))/ z/(z-1);
    end
end


%% 网络攻击实验结果at2
count = 100;
testnum = 100;
z = 40224;
load("G:\ywy\00毕业论文\实验\关联网络\网络数据\0412\attack_test2_dh0\dh0list.mat");

p_aver_list = zeros(length(dh0list),testnum);
name1 = ['D:\毕业论文\网络攻击结果\dh'];

name2 = ['\p_count'];

name3 = ['_quota'];
name4 = ['_k'];
name5 = ['.mat'];
p_0list = zeros(length(dh0list),testnum);
p_mid_list = zeros(length(dh0list),testnum);
V_list = zeros(length(dh0list),testnum);

% for d = 1:length(dh0list)
for d = 1:24
dh = dh0list(d);

p_list = zeros(count,testnum);
for test = 1:testnum
    quota = 0.01*test;
    failn = 40224 * quota;
    for i = 1:count
        name = [name1 num2str(d) name2 num2str(count) '_dh0' num2str(dh) name3 num2str(quota) name4 num2str(i) name5 ];
        p = cell2mat(struct2cell(load(name)));
        % p_list(i,test) = p*(failn*(failn - 1))/ z/(z-1);
        p_list(i,test) = p;
    end
end
p_0list(d,:) = p_list(1,end);

% p_mid_list(d,:) = median(p_list);
p_aver_list = sum(p_list)./count;
V_list(d,:) = p_aver_list;
end
load("G:\ywy\00毕业论文\实验\关联网络\网络数据\0416\attack_test2_dh0\p.mat");
V_list = V_list ./ p0;



%% 求平均值
p_aver_list = sum(p_list)./100;

p_0 = 0.0263;



%% 计算脆弱性
V_aver_list = p_aver_list ./ p_0list;
V_mid_list = p_mid_list ./ p_0list;


%% 画图

%随机攻击
% 横坐标：失效比例
% 纵坐标：脆弱性

% 箱式图
x = [0.01:0.01:0.8];

for i = 1:count
    y = p_list(i,:);
    boxplot(p_list,x); hold on;
end


% 点图

x = [0.01:0.01:1];
plot(x,V_list,'o');
axis([0 0.8 0 1]);


%% 拟合数据

% 数据
xdata = [1:100];
ydata = V_mid_list(1,:);

% 定义模型函数（指数模型）
modelFun = @(params, x) params(1) * x .^ params(2) + params(3);

% 初始参数猜测
initialParams = [0.3, 0.3, 0];

% 拟合
[coefficients, ~, ~] = nlinfit(xdata', ydata', modelFun, initialParams);

% 输出结果
disp("拟合参数：");
disp("a = " + coefficients(1));
disp("b = " + coefficients(2));
disp("c = " + coefficients(3));

% 可视化
xline = [1:100];
yfit = modelFun(coefficients, xline);
figure;
plot(xdata, ydata, 'ro', xline, yfit, 'b-');
legend('原始数据', '拟合曲线');
xlabel('x'); ylabel('y');


