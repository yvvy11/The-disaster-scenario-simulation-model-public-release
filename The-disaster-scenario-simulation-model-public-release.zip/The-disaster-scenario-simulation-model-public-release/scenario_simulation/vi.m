% 计算该点的脆弱性Vit


function [Vit] = vi(S_t,Vi0,sig)
z = size(S_t);
Vit = Vi0;

for i = 1:z
    if S_t(i) >=0 && S_t(i) < 1
        Vit(i) = Vi0(i) * (1+(1-exp(-sig*S_t(i)))/(1+exp(-sig*(S_t(i)-1))));
    elseif S_t(i) == 1
        Vit(i) = 0;
    end
end

end