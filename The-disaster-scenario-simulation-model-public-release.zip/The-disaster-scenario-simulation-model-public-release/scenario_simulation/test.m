clc;
clear;
for cycle_num = 1:1

theta = 0.5;
sig = 5;
miu = 5;
tau = 10;
% rc = 0.1 * cycle_num;

S_light = 0.25;
S_severe = 0.6;



testnum = 13 + cycle_num;
dh0=1.5;
rc=0.105;


cycle_index = 300;
chushu = 1;
building_type_num = 4;
lisan_num = 10;
savepath = ['outputs' filesep 'scenario_results' filesep];
mkdir([savepath 'test' num2str(testnum)] );

% -----------------导入数据----------------------------

path = ['data' filesep 'scenario_inputs' filesep];

lumc_b = imread([path '建筑sp.tif']);
lumc_b = sortears(lumc_b);
lumc_b_index = imread([path 'degree.tif']);
[row,col] = size(lumc_b);


% 具体化的离散承灾体
xf_sp = imread([path '消防站.tif']);
dl_sp = imread([path '电力设施.tif']);
hgc_sp = imread([path '污水厂.tif']);
rq_sp = imread([path '燃气设施.tif']);
ld_sp = double(imread([path '经济作物.tif']));
sl_sp = double(imread([path '水利设施.tif']));
hlsy_sp = imread([path '河流湖泊.tif']);
dljt_sp = imread([path '交通枢纽.tif']);
ck_sp = imread([path '物流仓储.tif']);
wwgj_sp = imread([path '文物古迹.tif']);


% 将具体化后的承灾体重新排序由1开始
% 并将其放在同一个数组lisan里
% 因为上一步的具体化中，一些面积太小的要素就会被arcgis自动忽略，导致序号不连续，这一步的工作就是要使得承灾体的序号连续
lisan = zeros([size(dljt_sp),10]);
lisan(:,:,10) = sortears(ld_sp);
lisan(:,:,7) = sortears(dl_sp);
lisan(:,:,9) = sortears(wwgj_sp);
lisan(:,:,5) = sortears(rq_sp);
lisan(:,:,8) = sortears(dljt_sp);
lisan(:,:,4) = sortears(sl_sp);
lisan(:,:,3) = sortears(xf_sp);
lisan(:,:,1) = sortears(hgc_sp);
lisan(:,:,6) = sortears(ck_sp);
lisan(:,:,2) = sortears(hlsy_sp);
weight = [8,10,7,6,4,9,2,5,3,1];%数组中的值表示第index个危险的承灾体的lu类型序号5~14
weight = weight + building_type_num;
seq = [10,7,9,5,8,4,3,1,6,2];



% 初始化2 离散承灾体具体化数组和土地利用数组的构建
% 将不同类型的离散承灾体合并成一个数组lumc_sp，土地利用类型用lumc表示
lumc_sp = lisan(:,:,1);
lumc = zeros(row,col);
lumc(lisan(:,:,1)~=0) = weight(1); %将数组中不为0的值都取1

for k = 2:10
    Maxx = max(max(lumc_sp));
    t = lisan(:,:,k);
    % 将t中的栅格加入lumc_sp里，如果该点原来有值了，那么不导入，如果没值，就导入
    for i = 1:row
        for j = 1:col
            if lumc_sp(i,j)==0 && t(i,j)~=0 % 表示（i，j）处没有比当前更重要的承灾体
                lumc_sp(i,j) = t(i,j) + Maxx; % 输入当前的承灾体
                lumc(i,j) = weight(k); % 该承灾体的土地利用类型序号
            end
        end
    end
    lumc_sp = sortears(lumc_sp);
end



url1 = fullfile('data', 'scenario_inputs', 'dc-matrix.xlsx');

% 离散化
% 输出ears_xx：[序号，lu属性，栅格数]
ears_lisan = separate_sp(lumc_sp,lumc);
ears_b = separate_sp(lumc_b,lumc_b_index);

% 找xy坐标：findxy函数
% 输出xy_xx：[序号，lu属性，x坐标，y坐标]
xy_b = find_xy(lumc_b,double(lumc_b_index));
xy_lisan = find_xy(lumc_sp,lumc);
% save([savepath 'test' num2str(testnum) '\xy_b.mat'],'xy_b');
% save([savepath 'test' num2str(testnum) '\xy_lisan.mat'],'xy_lisan');

grids_discrete = set_grids(lumc_sp, lumc);
grids_building = set_grids(lumc_b);

dc = xlsread(url1);
dc = dc(3:end,:);
[num_hp,n] = size(dc);


num = zeros(1,building_type_num+lisan_num);
for i = 1:length(ears_lisan)
    % 对应ears_lisan的第1、2列，分配
    j = ears_lisan(i,2);
    num(j) = num(j) + 1;
end

for i = 1:length(ears_b)
    j = ears_b(i,2);
    num(j) = num(j) + 1;
end

% save([savepath 'test' num2str(testnum) '\num.mat'],'num');

dc_sp = zeros(num_hp,sum(num));
k = 1;
for i = 1:n
    for j = k : k+num(i)-1
        dc_sp(:,j) = dc(:,i);
    end
    k = k+num(i);
end

[num_hp,z] = size(dc_sp);



%

% 构建初始ds/参考郄子君论文中设置的值
ds = zeros(z,1);

ds_set = [2,4,6,7,8,9,10;1,2,1,2,4,1,2];
ds_set(1,:) = ds_set(1,:) + building_type_num; 
[~,k] = size(ds_set);
for i = 1:k
    j = ds_set(1,i);
    index = sum(num(1:j-1));
    ds(index+1:index+num(j)) = ds_set(2,i);

end

ds_t = zeros(size(ds));
pri_b = [ 0.45, 0.35, 0.3, 0.25];
pri_lisan = [0.45,0.35,0.2,0.3,0.2,0.3,0.2,0.25,0.3,0.4];
% pri = [ 0.45, 0.35, 0.3, 0.25, 0.6,0.35,0.3,0.2,0.3,0.2,0.25,0.3,0.4,0.2];
pri = [ 0.45, 0.35, 0.3, 0.25, 0.45,0.35,0.2,0.3,0.2,0.3,0.2,0.25,0.3,0.4];

Di0_b = 1;
Di0_lisan = [0,1,0,2,0,3,4,10,2,5];
di0 = [1,1,1,1,0,1,0,2,0,3,4,10,2,5];


% 脆弱性属性集Vit

V0 = zeros(z,1);
for i = 1:z
    V0(i) = V0(i) + Vit2_sp(i,pri,num);
end

% 设置承灾体转化为致灾因子后的最大危险属性集Di0
Di0 = zeros(z,1);


for i = 1:z
    Di0(i) = Vit2_sp(i,di0,num);
end


% 计算得到初始状态Si_0

DH0 = dh0*ones(z,1);

Si_0 = V0 .* DH0;

index1 = find(Si_0>1);
Si_0(index1) = 1;

S_t = Si_0;



% 判断是否变成致灾因子
% 1、判断ears的类型，是I或II则进行下一步，不是则不会变成致灾因子

ir = zeros(z,z);

for hp = 1:num_hp
    for ei = 1:z
        for j = 1:z
            if j ~= ei && dc_sp(hp,j) ~= 0
                if dc_sp(hp,ei) == 3
                    ir(ei,j) = 1;
                elseif (dc_sp(hp,ei)==2)&&(dc_sp(hp,j)~=3)
                    ir(ei,j) = 1;
                end
            end
        end
    end
end
save([savepath 'test' num2str(testnum) '\ir.mat'],'ir');


                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               save([savepath 'test' num2str(testnum) '\S_t-0.mat'],'S_t');

%% ------循环开始的地方
ds_t = zeros(size(ds_t));
Di_t = zeros(size(Di0));

for count = 1:cycle_index
    SS_t = S_t;
    tic;
    % 2、判断Sit是否大于Slight，是则进行下一步，不是则不会变成致灾因子
    for i =1:z
        if S_t(i) >= S_severe
            ds_t(i) = ds(i);
            Di_t(i) = Di0(i);
        elseif (S_t(i) < S_severe) && (S_t(i) > S_light)
            p = 2*S_t(i)-0.4;
            if randsrc(1,1,[0,1;p,1-p]) == 0 %说明会变成致灾因子
                ds_t(i) = ds(i);
                Di_t(i) = Di0(i);
            end
        end
    end



    % 计算承灾体脆弱性
    Vi = vi(S_t,V0,sig);
   

    % 计算S2t
    [S2t,Di_t,TM_ir_t] = S2_t(miu,theta,Vi,ds_t,ears_b,ears_lisan,Di_t,S_t,grids_building,grids_discrete,ir,lumc_b,lumc_sp);
    
    % 计算S1t
    S1t = S1_t(S_light,S_severe,tau,rc,S_t,Di_t);


    [TM,tm_row,tm_col] = extra_tm(TM_ir_t);
    save([savepath 'test' num2str(testnum) '\tm-' num2str(count) '.mat'],'TM');
    save([savepath 'test' num2str(testnum) '\tm_row-' num2str(count) '.mat'],'tm_row');
    save([savepath 'test' num2str(testnum) '\tm_col-' num2str(count) '.mat'],'tm_col');
    save([savepath 'test' num2str(testnum) '\Dit-' num2str(count) '.mat'],'Di_t');
    


    % 计算承灾体状态，得到t时刻的Sit，一次循环结束，进入下一次循环
    S_t = S_t + S1t + S2t;


    % 判断承灾体状态能否进入下一次循环
    for i =1:z
        if S_t(i) >= 1
            S_t(i) = 1;
        elseif S_t(i) < 0
            S_t(i) = 0;
        end
    end


save([savepath 'test' num2str(testnum) '\S_t-' num2str(count) '.mat'],'S_t');
save([savepath 'test' num2str(testnum) '\S1t-' num2str(count) '.mat'],'S1t');
save([savepath 'test' num2str(testnum) '\S2t-' num2str(count) '.mat'],'S2t');

    % %% 画图
    % 
    % %对于建筑
    % figure(1);
    % out_b =  zeros([row,col]);
    % s1 = zeros([row,col]);
    % % for x = 1:row
    % %     for y = 1:col
    % %         n = findS(x,y,xy_b);
    % %         if n ~= 0
    % %             out_b(x,y) = S_t(n);
    % %             s1(x,y) = 1;
    % %         end
    % %     end
    % % end
    % 
    % for i = 1:size(xy_b,1)
    %     x = xy_b(i,3);
    %     y = xy_b(i,4);
    %     if xy_b(i,1)~=0
    %         out_b(x,y) = S_t(xy_b(i,1));
    %         s1(x,y) = 1;
    %     end
    % end
    % h1=image(256 - out_b*256);
    % colormap summer;
    % c = colorbar;
    % c.Location = 'southoutside';
    % c.Ticks = [1 150 255];
    % c.TickLabels = {'状态较差','状态一般','状态相对较好'};
    % title(sprintf('test%d 建筑：第%d次演化',testnum, count));
    % set(h1,'alphadata',s1);
    % saveas(1,[savepath 'test' num2str(testnum) '\' '建筑' num2str(count) '.jpg']);
    % 
    % % 对于离散要素
    % figure(2);
    % out_lisan = zeros([row,col]);
    % s2 = zeros([row,col]);
    % % for x = 1:row
    % %     for y = 1:col
    % %         n = findS(x,y,xy_lisan);
    % %         if n ~= 0
    % %             out_lisan(x,y) = S_t(n+sum(num(1:building_type_num)));
    % %             s2(x,y) = 1;
    % %         end
    % %     end
    % % end
    % for i = 1:size(xy_lisan,1)
    %     x = xy_lisan(i,3);
    %     y = xy_lisan(i,4);
    %     if xy_lisan(i,1)~=0
    %         out_lisan(x,y) = S_t(xy_lisan(i,1)+sum(num(1:building_type_num)));
    %         s2(x,y) = 1;
    %     end
    % end
    % 
    % h2 = image(256 - out_lisan*256);
    % colormap summer;
    % c = colorbar;
    % c.Location = 'southoutside';
    % c.Ticks = [1 150 255];
    % c.TickLabels = {'状态较差','状态一般','状态相对较好'};
    % title(sprintf('test%d 离散承灾体：第%d次演化', testnum, count));
    % set(h2,'alphadata',s2);
    % saveas(2,[savepath 'test' num2str(testnum) '\' '离散' num2str(count) '.jpg']);
    
      toc;
   
      check = find(S_t~=0 & S_t~=1);
      if size(check,1) == 0 
          break
      end

      if sum(SS_t - S_t) == 0
          break
      end



end
end

%% 致灾因子形成的概率分布函数


function p = P(S,a,b)
if S >= a && S < b
    p = 2*S-0.4;
elseif S >= 0 && S < a
    p = 0;
elseif S >= b
    p = 1;
end
end


%% 找xy坐标
% 输入：ears表示具体化后的承灾体栅格，n表示承灾体类型，1表示人口、建筑，2表示离散
% 输出：每一个栅格点的序号、值、x坐标、y坐标
function [out] = find_xy(ears,lumc)
[row,col] = size(ears);
out = zeros(row*col,4);
k=1;

for i = 1:row
    for j = 1:col
        out(k,:)=[ears(i,j),lumc(i,j),i,j];
        k=k+1;
    end
end

end

%% separate_sp 函数
%
function [out] = separate_sp(ears,lumc)
[row,col] = size(ears);
Max = max(max(ears));
out = zeros(Max,3);
out(:,1) =  (1:Max)';
num = zeros(Max,2);
num(:,1) = (1:Max)';

% 计算每个具体要素（代码）中的栅格数目：num（代码，个数）
for i = 1:row
    for j = 1:col
        value = ears(i,j);
        if value > 0
            num(value,2) = num(value,2)+1;
            out(value,2) = lumc(i,j);
        end
    end
end

% 给每一个代码赋予属性值，属性值存储在lumc260299里面


out(:,3) = num(:,2);

end

%%

function s = findS(x,y,xy)
for i = 1:size(xy)
    if xy(i,3) == x && xy(i,4) == y
        s = xy(i,1);
    end
end
end




%% 用于对sp后的承灾体进行排序

function ear = sortears(ear_sp)
[p,q] = size(ear_sp);
ear = zeros(p,q);
k = 1;
t = tabulate(reshape(ear_sp,[1,p*q]));
totalnum = size(t,1)-1; % 表示所有有值的数的总个数
for i = 1:totalnum
    v = t(i+1,1); %v表示统计出的第i个数的值
    [r,c] = find(ear_sp==v);
    n = length(r);
    for j = 1:n
        ear(r(j),c(j)) = k;
    end
    k = k + 1;
end


end


%% Vit2用于得到承灾体的初始脆弱性数值
% 输入i表示该承灾体的z代码，pri表示离散承灾体的脆弱性数组
% 输出i对应的脆弱性数值
function out = Vit2_sp(id,pri,num)
i = 1;
flag = 100;
while(flag == 100)
    id = id - num(i);
    if id <= 0
        out = pri(i);
        flag = 0;
    else
        i = i + 1;
    end
end
end

function [s1] = S1_t(S_light,S_severe,t,rc,S_t,Di_t)
s1=zeros(size(S_t));
for i = 1:size(S_t)
    
    if (S_t(i) > S_light) && (S_t(i) <= S_severe)
        % s1(i) = -rc + S_t(i)/t;
        s1(i) = -rc/2 + S_t(i)/t;
    elseif (S_t(i) > 0) && (S_t(i) <= S_light)
        % s1(i) = -rc;
        s1(i) = -rc/2;
    elseif (S_t(i) > S_severe) && (S_t(i) < 1)
        s1(i) = S_t(i)/t;
    elseif (S_t(i) == 1) 
        s1(i) = 0;
    elseif (S_t(i) == 0)
        if Di_t(i) ~= 0
            s1(i) = -rc/2;
        else
            s1(i) = 0;
        end
    end
end

end
