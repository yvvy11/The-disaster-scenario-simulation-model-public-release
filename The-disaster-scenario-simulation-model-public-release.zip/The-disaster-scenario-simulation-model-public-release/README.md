# The disaster-scenario simulation model based on EaRs interrelation network

This repository contains the public-release core code for the urban flood
disaster-scenario simulation model described in the associated manuscript.

## Contents

- `network`:  edge-weight builder.
- `scenario_simulation`: scenario runner for public-format inputs.

## Model conventions

- Matrix rows are source EaRs and columns are target EaRs.
- Source activation is deterministic at `S >= 0.60`; no random seed is needed.
- Spatial propagation is limited by the source influence radius and weighted by
  inverse-square distance decay.
- Functional interrelations may transmit risk across that spatial-radius limit.
- The state at stage `t` is calculated from the state at stage `t-1`, its
  self-change and cumulative external impacts.
