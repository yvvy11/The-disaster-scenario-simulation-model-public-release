% 计算si、ei、rc均值

%% si计算
% 导入si的tif文件
input_dir = fullfile('data', 'parameter_preprocessing');
scenario_data_dir = fullfile('data', 'scenario_inputs');
output_dir = fullfile('outputs', 'parameter_preprocessing');

buffer = imread(fullfile(input_dir, 'buffer.tif'));
si = imread(fullfile(input_dir, 'SI.tif'));

xy_b = cell2mat(struct2cell(load(fullfile(scenario_data_dir, 'xy_b.mat'))));
xy_lisan = cell2mat(struct2cell(load(fullfile(scenario_data_dir, 'xy_lisan.mat'))));

[z,~] = size(xy_lisan);

idx = xy_lisan(:,1);
max_idx = max(idx);
max_ears = max_idx;

lisan_list = zeros(max_idx,3);

for i = 1:z
    if xy_lisan(i,1) ~= 0
        lisan_list(xy_lisan(i,1),1) = xy_lisan(i,1);
        lisan_list(xy_lisan(i,1),2) = lisan_list(xy_lisan(i,1),2) + si(xy_lisan(i,3),xy_lisan(i,4));
        lisan_list(xy_lisan(i,1),3) = lisan_list(xy_lisan(i,1),3) + 1;
    end
end
si_list = lisan_list(:,2)./lisan_list(:,3);
save(fullfile(output_dir, 'si_list.mat'),'si_list');

%% 暴露度计算Ei
ears_raster = [9386, 13928, 2008, 296, 691, 1159, 895, 7, 6, 442, 1790];
e_list = ears_raster / 126249.0;
save(fullfile(output_dir, 'ei_list.mat'),'e_list');


%% rc计算
% 导入eci、hci、fci（每一类承灾体单独算）
% 1、dl
dl_eci = imread(fullfile(input_dir, 'dl_ECI.tif'));
dl_hci = imread(fullfile(input_dir, 'dl_HCI.tif'));
dl_fci = imread(fullfile(input_dir, 'dl_FCI.tif'));
dl_ci = 0.14*dl_eci + 0.29*dl_fci + 0.57*dl_hci;
dl_xy = xy_lisan(xy_lisan(:,2)==5,:);
dl_ci_list = count_list(dl_ci,dl_xy,'dl');

% 2、wwgj
wwgj_eci = imread(fullfile(input_dir, 'wwgj_ECI.tif'));
wwgj_hci = imread(fullfile(input_dir, 'wwgj_HCI.tif'));
wwgj_fci = imread(fullfile(input_dir, 'wwgj_FCI.tif'));
wwgj_ci = 0.14*wwgj_eci + 0.29*wwgj_fci + 0.57*wwgj_hci;
wwgj_xy = xy_lisan(xy_lisan(:,2)==6,:);
wwgj_ci_list = count_list(wwgj_ci,wwgj_xy,'wwgj');

% 3、wsc
wsc_eci = imread(fullfile(input_dir, 'wsc_ECI.tif'));
wsc_hci = imread(fullfile(input_dir, 'wsc_HCI.tif'));
wsc_fci = imread(fullfile(input_dir, 'wsc_FCI.tif'));
wsc_ci = 0.14*wsc_eci + 0.29*wsc_fci + 0.57*wsc_hci;
wsc_xy = xy_lisan(xy_lisan(:,2)==11,:);
wsc_ci_list = count_list(wsc_ci,wsc_xy,'wsc');

% 4、wlcc
wlcc_eci = imread(fullfile(input_dir, 'wlcc_ECI.tif'));
wlcc_hci = imread(fullfile(input_dir, 'wlcc_HCI.tif'));
wlcc_fci = imread(fullfile(input_dir, 'wlcc_FCI.tif'));
wlcc_ci = 0.14*wlcc_eci + 0.29*wlcc_fci + 0.57*wlcc_hci;
wlcc_xy = xy_lisan(xy_lisan(:,2)==12,:);
wlcc_ci_list = count_list(wlcc_ci,wlcc_xy,'wlcc');

% 5、sl
sl_eci = imread(fullfile(input_dir, 'sl_ECI.tif'));
sl_hci = imread(fullfile(input_dir, 'sl_HCI.tif'));
sl_fci = imread(fullfile(input_dir, 'sl_FCI.tif'));
sl_ci = 0.14*sl_eci + 0.29*sl_fci + 0.57*sl_hci;
sl_xy = xy_lisan(xy_lisan(:,2)==9,:);
sl_ci_list = count_list(sl_ci,sl_xy,'sl');

% 6、rq
rq_eci = imread(fullfile(input_dir, 'rq_ECI.tif'));
rq_hci = imread(fullfile(input_dir, 'rq_HCI.tif'));
rq_fci = imread(fullfile(input_dir, 'rq_FCI.tif'));
rq_ci = 0.14*rq_eci + 0.29*rq_fci + 0.57*rq_hci;
rq_xy = xy_lisan(xy_lisan(:,2)==7,:);
rq_ci_list = count_list(rq_ci,rq_xy,'rq');

% 7、jtsn
jtsn_eci = imread(fullfile(input_dir, 'jtsn_ECI.tif'));
jtsn_hci = imread(fullfile(input_dir, 'jtsn_HCI.tif'));
jtsn_fci = imread(fullfile(input_dir, 'jtsn_FCI.tif'));
jtsn_ci = 0.14*jtsn_eci + 0.29*jtsn_fci + 0.57*jtsn_hci;
jtsn_xy = xy_lisan(xy_lisan(:,2)==8,:);
jtsn_ci_list = count_list(jtsn_ci,jtsn_xy,'dl');

% 8、jjzw
jjzw_eci = imread(fullfile(input_dir, 'jjzw_ECI.tif'));
jjzw_hci = imread(fullfile(input_dir, 'jjzw_HCI.tif'));
jjzw_fci = imread(fullfile(input_dir, 'jjzw_FCI.tif'));
jjzw_ci = 0.14*jjzw_eci + 0.29*jjzw_fci + 0.57*jjzw_hci;
jjzw_xy = xy_lisan(xy_lisan(:,2)==4,:);
jjzw_ci_list = count_list(jjzw_ci,jjzw_xy,'jjzw');

% 9、hlhp
hlhp_eci = imread(fullfile(input_dir, 'hlhp_ECI.tif'));
hlhp_hci = imread(fullfile(input_dir, 'hlhp_HCI.tif'));
hlhp_fci = imread(fullfile(input_dir, 'hlhp_FCI.tif'));
hlhp_ci = 0.14*hlhp_eci + 0.29*hlhp_fci + 0.57*hlhp_hci;
hlhp_xy = xy_lisan(xy_lisan(:,2)==13,:);
hlhp_ci_list = count_list(hlhp_ci,hlhp_xy,'hlhp');

% 10、xfc
xfz_eci = imread(fullfile(input_dir, 'xfz_ECI.tif'));
xfz_hci = imread(fullfile(input_dir, 'xfz_HCI.tif'));
xfz_ci = 0.14*xfz_eci + 0.29 + 0.57*xfz_hci;
xfz_xy = xy_lisan(xy_lisan(:,2)==10,:);
xfz_ci_list = count_list(xfz_ci,xfz_xy,'xfz');

%% 合并计算结果
ears_ci_list = zeros(max_ears,1);
% 1、dl
min_idx = min(dl_xy(:,1));
max_idx = max(dl_xy(:,1));
ears_ci_list(min_idx:max_idx) = dl_ci_list(min_idx:max_idx);
% 2、wwgj
min_idx = min(wwgj_xy(:,1));
max_idx = max(wwgj_xy(:,1));
ears_ci_list(min_idx:max_idx) = wwgj_ci_list(min_idx:max_idx);
% 3、wsc
min_idx = min(wsc_xy(:,1));
max_idx = max(wsc_xy(:,1));
ears_ci_list(min_idx:max_idx) = wsc_ci_list(min_idx:max_idx);
% 4、wlcc
min_idx = min(wlcc_xy(:,1));
max_idx = max(wlcc_xy(:,1));
ears_ci_list(min_idx:max_idx) = wlcc_ci_list(min_idx:max_idx);
% 5、sl
min_idx = min(sl_xy(:,1));
max_idx = max(sl_xy(:,1));
ears_ci_list(min_idx:max_idx) = sl_ci_list(min_idx:max_idx);
% 6、rq
min_idx = min(rq_xy(:,1));
max_idx = max(rq_xy(:,1));
ears_ci_list(min_idx:max_idx) = rq_ci_list(min_idx:max_idx);
% 7、jtsn
min_idx = min(jtsn_xy(:,1));
max_idx = max(jtsn_xy(:,1));
ears_ci_list(min_idx:max_idx) = jtsn_ci_list(min_idx:max_idx);
% 8、jjzw
min_idx = min(jjzw_xy(:,1));
max_idx = max(jjzw_xy(:,1));
ears_ci_list(min_idx:max_idx) = jjzw_ci_list(min_idx:max_idx);
% 9、hlhp
min_idx = min(hlhp_xy(:,1));
max_idx = max(hlhp_xy(:,1));
ears_ci_list(min_idx:max_idx) = hlhp_ci_list(min_idx:max_idx);
% 10、xfc
min_idx = min(xfz_xy(:,1));
max_idx = max(xfz_xy(:,1));
ears_ci_list(min_idx:max_idx) = xfz_ci_list(min_idx:max_idx);

save(fullfile(output_dir, 'ci_list.mat'),'ears_ci_list');

function i_list = count_list(ci,xy,name)
[z,~] = size(xy);
idx = xy(:,1);
max_idx = max(idx);
xi_list = zeros(max_idx,3);

for i = 1:z
    if xy(i,1) ~= 0
        xi_list(xy(i,1),1) = xy(i,1);
        xi_list(xy(i,1),2) = xi_list(xy(i,1),2) + ci(xy(i,3),xy(i,4));
        xi_list(xy(i,1),3) = xi_list(xy(i,1),3) + 1;
    end
end
i_list = xi_list(:,2)./xi_list(:,3);
save(fullfile('outputs', 'parameter_preprocessing', [name '_list.mat']),'i_list');
end
